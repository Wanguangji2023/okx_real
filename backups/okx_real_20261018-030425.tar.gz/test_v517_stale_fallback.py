#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v5.17 验证期补丁回归测试（保护 C12：无行情持仓 REST 兜底盯盘）

背景：模拟盘只有部分币对持续有成交推送，冷门币对持仓的止盈/回本清仓完全依赖 tick
会无限期停摆（实证 VINE 40s 内 0 条成交帧）。本测试只测纯逻辑 + 内存假客户端，
不触碰任何真实 API 与真实账本。
运行: /home/ubuntu/venv/bin/python3 test_v517_stale_fallback.py
"""
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import okx_autoTrade_TrytoConnectOKX1 as mod
from test_okx_strategy import make_state
from test_v516_batch2 import TempFilesMixin


class TestLogWhitelist(unittest.TestCase):
    """C12 补充：trade_event INFO 必须落 run.log（兜底启用/交易事件不再只飘控制台）"""

    def test_trade_event_info_written(self):
        import tempfile
        lg = mod.Logger(os.path.join(tempfile.mkdtemp(prefix="okx_v517_log_"), "t.log"))
        self.assertTrue(lg._should_write_log("INFO", "trade_event"))
        self.assertTrue(lg._should_write_log("INFO", "startup"))
        self.assertTrue(lg._should_write_log("WARN", "任何分类"))
        self.assertTrue(lg._should_write_log("ERROR", "任何分类"))
        self.assertFalse(lg._should_write_log("DEBUG", "trade_event"))


class TestFetchTickerPrice(unittest.TestCase):
    """fetch_ticker_price：公开接口最新价解析与失败回退"""

    class FakeClient:
        def __init__(self, payload=None, exc=None):
            self.payload = payload
            self.exc = exc
            self.calls = []

        def _request(self, method, path, body_obj=None, query=None, auth=True, timeout=10):
            self.calls.append((method, path, query, auth))
            if self.exc:
                raise self.exc
            return self.payload or {}

    def setUp(self):
        self._orig = mod._okx_client

    def tearDown(self):
        mod._okx_client = self._orig

    def test_parses_last_price(self):
        client = self.FakeClient({"data": [{"instId": "VINE-USDT", "last": "0.93459"}]})
        mod._okx_client = client
        self.assertAlmostEqual(mod.fetch_ticker_price("VINE-USDT"), 0.93459)
        # 必须是公开接口（auth=False），且带上 instId
        self.assertEqual(client.calls[0][0], "GET")
        self.assertIn("/api/v5/market/ticker", client.calls[0][1])
        self.assertEqual(client.calls[0][2], {"instId": "VINE-USDT"})
        self.assertFalse(client.calls[0][3])

    def test_none_without_client(self):
        mod._okx_client = None
        self.assertIsNone(mod.fetch_ticker_price("VINE-USDT"))

    def test_none_on_exception(self):
        mod._okx_client = self.FakeClient(exc=RuntimeError("boom"))
        self.assertIsNone(mod.fetch_ticker_price("VINE-USDT"))

    def test_none_on_empty_or_bad_price(self):
        mod._okx_client = self.FakeClient({"data": []})
        self.assertIsNone(mod.fetch_ticker_price("VINE-USDT"))
        mod._okx_client = self.FakeClient({"data": [{"last": "0"}]})
        self.assertIsNone(mod.fetch_ticker_price("VINE-USDT"))
        mod._okx_client = self.FakeClient({"data": [{"last": ""}]})
        self.assertIsNone(mod.fetch_ticker_price("VINE-USDT"))


class TestStaleFallback(TempFilesMixin, unittest.TestCase):
    """引擎级：无行情持仓的兜底轮询（喂 tick / 跳过 / 限流 / 轮转）"""

    def setUp(self):
        super().setUp()
        self._orig_fetch = mod.fetch_ticker_price
        self._orig_max = mod.STALE_POLL_MAX_PER_CYCLE
        self.calls = []

        def fake_fetch(inst_id):
            self.calls.append(inst_id)
            return 1.05

        mod.fetch_ticker_price = fake_fetch

    def tearDown(self):
        mod.fetch_ticker_price = self._orig_fetch
        mod.STALE_POLL_MAX_PER_CYCLE = self._orig_max
        super().tearDown()

    def _engine(self, *states):
        engine = mod.MarketEngine(mod.Logger(os.devnull))
        for st in states:
            engine.states[st.inst_id] = st
        engine._last_stale_poll_ts = 0.0
        return engine

    def _mk(self, inst_id, stale_age=1000.0, env_missing=False, has_pos=True):
        st = make_state(inst_id=inst_id, has_position=has_pos, position_price=1.0,
                        position_qty=10.0, position_amount=10.0)
        st._save_state = lambda force=False: None
        st._push_notify = lambda t: None
        st.last_tick_ts = time.time() - stale_age
        st._env_missing = env_missing
        return st

    def test_stale_held_state_fed(self):
        st = self._mk("A-USDT")
        engine = self._engine(st)
        self.assertEqual(engine._poll_stale_positions(), 1)
        self.assertEqual(self.calls, ["A-USDT"])
        # 价格已喂入 update_price 路径（止盈/卖出评估就地生效）
        self.assertAlmostEqual(st._last_processed_price, 1.05)
        self.assertGreater(st.last_tick_ts, time.time() - 5)

    def test_recent_tick_not_fed(self):
        st = self._mk("B-USDT", stale_age=10.0)   # 10 秒前还有行情 → 不兜底
        engine = self._engine(st)
        self.assertEqual(engine._poll_stale_positions(), 0)
        self.assertEqual(self.calls, [])

    def test_env_missing_skipped(self):
        st = self._mk("C-USDT", env_missing=True)  # 当前环境无此产品（REST 也查不到）
        engine = self._engine(st)
        self.assertEqual(engine._poll_stale_positions(), 0)
        self.assertEqual(self.calls, [])

    def test_not_held_not_fed(self):
        st = self._mk("D-USDT", has_pos=False)
        engine = self._engine(st)
        self.assertEqual(engine._poll_stale_positions(), 0)
        self.assertEqual(self.calls, [])

    def test_max_per_cycle_and_rotation(self):
        mod.STALE_POLL_MAX_PER_CYCLE = 1
        a, b = self._mk("E-USDT"), self._mk("F-USDT")
        engine = self._engine(a, b)
        self.assertEqual(engine._poll_stale_positions(), 1)
        first = self.calls[:]
        # 下一轮（节流重置）应轮到另一个（按"最久未被兜底"排序）
        engine._last_stale_poll_ts = 0.0
        self.assertEqual(engine._poll_stale_positions(), 1)
        self.assertEqual(sorted(self.calls), sorted(["E-USDT", "F-USDT"]))
        self.assertNotEqual(first, self.calls[-1:])

    def test_interval_throttle(self):
        st = self._mk("G-USDT")
        engine = self._engine(st)
        self.assertEqual(engine._poll_stale_positions(), 1)
        # 同一轮节流期内再调：不再发第二个 REST
        self.assertEqual(engine._poll_stale_positions(), 0)
        self.assertEqual(self.calls, ["G-USDT"])

    def test_selling_position_shorter_threshold(self):
        st = self._mk("H-USDT", stale_age=150.0)   # 普通阈值 300s 不满足
        st._sell_blocked_until = time.time() - 5   # 卖出重试中 → 阈值 120s，满足
        engine = self._engine(st)
        self.assertEqual(engine._poll_stale_positions(), 1)
        self.assertEqual(self.calls, ["H-USDT"])

    def test_selling_position_priority(self):
        a = self._mk("I-USDT", stale_age=1000.0)   # 普通休眠，更久未喂
        b = self._mk("J-USDT", stale_age=130.0)    # 卖出重试中
        b._sell_blocked_until = time.time() - 1
        mod.STALE_POLL_MAX_PER_CYCLE = 1
        engine = self._engine(a, b)
        self.assertEqual(engine._poll_stale_positions(), 1)
        self.assertEqual(self.calls, ["J-USDT"])   # 卖出重试中优先，不被普通休眠抢占名额

    def test_update_price_records_tick_time(self):
        st = make_state()
        self.assertEqual(st.last_tick_ts, 0.0)
        st._save_state = lambda force=False: None
        st._push_notify = lambda t: None
        st.update_price(1.0, 5.0)
        self.assertGreater(st.last_tick_ts, 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
